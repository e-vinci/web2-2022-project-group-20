create view membres_infos
            (id_membre, email, nom, prenom, is_admin, image_profil, balance, nbr_annonces_postee,
             nbr_annonces_vendues) as
SELECT m.id_membre,
       m.email,
       m.nom,
       m.prenom,
       m.is_admin,
       m.image_profil,
       m.balance,
       count(a.id_annonce) AS nbr_annonces_postee,
       count(
               CASE
                   WHEN a.status = 'Vendue'::vinced.status THEN a.id_annonce
                   ELSE NULL::integer
                   END)    AS nbr_annonces_vendues
FROM vinced.membres m
         LEFT JOIN vinced.annonces a ON m.id_membre = a.id_vendeur
GROUP BY m.id_membre, m.nom, m.prenom, m.is_admin, m.balance;

alter table membres_infos
    owner to zkyiherr;

