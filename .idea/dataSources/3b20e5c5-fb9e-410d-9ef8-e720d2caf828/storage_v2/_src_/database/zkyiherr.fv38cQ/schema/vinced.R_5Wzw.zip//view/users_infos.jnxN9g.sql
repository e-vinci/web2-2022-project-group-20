create view users_infos (id_membre, nom, prenom, is_admin, balance, annonces_postee, annonces_vendues) as
SELECT m.id_membre,
       m.nom,
       m.prenom,
       m.is_admin,
       m.balance,
       count(a.id_annonce) AS annonces_postee,
       count(
               CASE
                   WHEN a.status = 'Vendue'::vinced.status THEN a.id_annonce
                   ELSE NULL::integer
                   END)    AS annonces_vendues
FROM vinced.membres m
         LEFT JOIN vinced.annonces a ON m.id_membre = a.id_vendeur
GROUP BY m.id_membre, m.nom, m.prenom, m.is_admin, m.balance;

alter table users_infos
    owner to zkyiherr;

