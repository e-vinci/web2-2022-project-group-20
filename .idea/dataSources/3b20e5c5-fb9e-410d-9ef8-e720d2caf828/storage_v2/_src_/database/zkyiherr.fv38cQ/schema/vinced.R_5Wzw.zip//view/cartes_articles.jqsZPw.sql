create view cartes_articles
            (id_annonce, nom_article, description, prix, date_pub, photo, status, categorie, id_acheteur, nom_acheteur,
             prenom_acheteur, id_vendeur, nom_vendeur, prenom_vendeur)
as
SELECT a.id_annonce,
       a.nom        AS nom_article,
       a.description,
       a.prix,
       a.date_pub,
       a.photo,
       a.status,
       c.nom        AS categorie,
       ma.id_membre AS id_acheteur,
       ma.nom       AS nom_acheteur,
       ma.prenom    AS prenom_acheteur,
       mv.id_membre AS id_vendeur,
       mv.nom       AS nom_vendeur,
       mv.prenom    AS prenom_vendeur
FROM vinced.annonces a
         LEFT JOIN vinced.membres ma ON ma.id_membre = a.id_acheteur
         JOIN vinced.membres mv ON a.id_vendeur = mv.id_membre
         JOIN vinced.categories c ON a.categorie = c.id_categorie;

alter table cartes_articles
    owner to zkyiherr;

